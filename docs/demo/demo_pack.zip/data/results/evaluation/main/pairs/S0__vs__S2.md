**S0** (`pitie_fixed`) vs **S2** (`pitie_rules`), family `main`, role *confirmatory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S0 mean ± sd | S2 mean ± sd | S2 − S0 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 75.9 ± 12.9 | 56.6 ± 7.2 | -19.3 [-24.2, -14.4] s | -25.4 % | 0.0020 | 0.0137 | better | no |
| car | `wait_p95` | 164.5 ± 26.3 | 111.6 ± 19.9 | -52.8 [-64.1, -41.5] s | -32.1 % | 0.0020 | 0.0137 | better | no |
| bus | `delay_mean` | 61.0 ± 1.1 | 56.1 ± 4.0 | -4.9 [-7.9, -1.9] s | -8.0 % | 0.0098 | 0.0293 | better | no |
| bus | `headway_std` | 23.4 ± 0.3 | 23.3 ± 3.2 | -0.1 [-2.4, 2.2] s | -0.4 % | 0.9219 | 0.9219 | better | no |
| pedestrian | `ped_wait_mean` | 21.8 ± 0.7 | 22.3 ± 0.8 | +0.5 [-0.1, 1.1] s | 2.4 % | 0.1309 | 0.2617 | worse | no |
| pedestrian | `ped_wait_single_max` | 85.6 ± 0.5 | 88.0 ± 0.0 | +2.4 [2.0, 2.8] s | 2.8 % | 0.0020 | 0.0137 | worse | no |
| ambulance | `time_loss_mean` | 109.2 ± 52.5 | 76.7 ± 41.6 | -32.5 [-57.5, -7.4] s | -29.7 % | 0.0059 | 0.0234 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- bus `depart_delay_mean`: 0.137 → 0.161 s (+17.1 %, p 0.0156)
- bus `depart_delay_max`: 3.00 → 5.20 s (+73.3 %, p 0.0156)
- car `time_loss_mean__arm_S`: 44.1 → 48.4 s (+9.6 %, p 0.0020)
- car `delay_total_mean__arm_S`: 44.1 → 48.4 s (+9.8 %, p 0.0020)
- bus `delay_mean__flow_57_N`: 53.5 → 59.9 s (+11.8 %, p 0.0645)
- bus `headway_std__line_57`: 23.4 → 27.7 s (+18.1 %, p 0.0488)
- pedestrian `ped_wait_single_mean__crossing_NB`: 8.63 → 9.11 s (+5.6 %, p 0.1309)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.46 → 6.87 s (+6.3 %, p 0.2324)
- pedestrian `ped_wait_single_mean__crossing_W`: 27.8 → 29.5 s (+6.0 %, p 0.0371)
- pedestrian `ped_wait_single_max__crossing_NB`: 40.9 → 45.3 s (+10.8 %, p 0.0156)
- pedestrian `ped_wait_single_max__crossing_WB`: 40.9 → 44.8 s (+9.5 %, p 0.0039)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.00 → 7.42 s (+5.9 %, p 0.3223)
- pedestrian `ped_curb_wait_mean__crossing_W`: 29.1 → 30.9 s (+6.0 %, p 0.0371)
- pedestrian `ped_curb_wait_max__crossing_NB`: 41.2 → 45.9 s (+11.4 %, p 0.0117)
- pedestrian `ped_curb_wait_max__crossing_WB`: 40.9 → 45.2 s (+10.5 %, p 0.0039)
- junction `exit_blocked_s`: 24.5 → 26.7 s (+9.0 %, p 0.3555)
- junction `exit_blocked_green_s`: 1.8 → 10.8 s (+500.0 %, p 0.0020)
