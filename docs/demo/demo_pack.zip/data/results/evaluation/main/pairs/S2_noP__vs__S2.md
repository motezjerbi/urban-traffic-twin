**S2_noP** (`pitie_rules_nopreempt`) vs **S2** (`pitie_rules`), family `main`, role *exploratory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S2_noP mean ± sd | S2 mean ± sd | S2 − S2_noP [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 55.9 ± 6.7 | 56.6 ± 7.2 | +0.7 [-0.4, 1.8] s | 1.2 % | 0.2754 | 1.0000 | worse | no |
| car | `wait_p95` | 109.6 ± 19.7 | 111.6 ± 19.9 | +2.1 [-0.2, 4.4] s | 1.9 % | 0.0879 | 0.5273 | worse | no |
| bus | `delay_mean` | 57.2 ± 5.4 | 56.1 ± 4.0 | -1.1 [-4.4, 2.3] s | -1.9 % | 0.5566 | 1.0000 | better | no |
| bus | `headway_std` | 23.4 ± 3.5 | 23.3 ± 3.2 | -0.1 [-2.5, 2.3] s | -0.4 % | 0.9219 | 1.0000 | better | no |
| pedestrian | `ped_wait_mean` | 22.1 ± 0.6 | 22.3 ± 0.8 | +0.2 [-0.2, 0.6] s | 1.1 % | 0.2754 | 1.0000 | worse | no |
| pedestrian | `ped_wait_single_max` | 88.0 ± 0.0 | 88.0 ± 0.0 | +0.0 [0.0, 0.0] s | 0.0 % | 1.0000 | 1.0000 | same | no |
| ambulance | `time_loss_mean` | 100.6 ± 43.0 | 76.7 ± 41.6 | -23.9 [-42.8, -5.0] s | -23.7 % | 0.0039 | 0.0273 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- bus `depart_delay_max`: 4.60 → 5.20 s (+13.0 %, p 0.3438)
- car `time_loss_mean__arm_W`: 63.7 → 69.5 s (+9.0 %, p 0.0039)
- car `delay_total_mean__arm_W`: 63.8 → 69.5 s (+9.0 %, p 0.0039)
- bus `delay_mean__flow_91_W`: 51.6 → 54.6 s (+5.7 %, p 0.3750)
- bus `headway_std__line_91`: 26.3 → 28.7 s (+9.4 %, p 0.3223)
- junction `box_halt_red_s`: 34.6 → 41.5 s (+19.9 %, p 0.3594)
- junction `box_foe_onsets`: 1.50 → 2.50 (+66.7 %, p 0.1406)
- junction `exit_blocked_s`: 24.1 → 26.7 s (+10.8 %, p 0.2031)
- junction `exit_blocked_green_s`: 9.1 → 10.8 s (+18.7 %, p 0.1562)
