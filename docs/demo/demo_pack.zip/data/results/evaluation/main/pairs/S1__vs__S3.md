**S1** (`pitie_actuated`) vs **S3** (`pitie_rl_s3`), family `main`, role *confirmatory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S1 mean ± sd | S3 mean ± sd | S3 − S1 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 65.8 ± 11.3 | 56.2 ± 4.3 | -9.6 [-15.1, -4.0] s | -14.5 % | 0.0020 | 0.0137 | better | no |
| car | `wait_p95` | 140.0 ± 22.7 | 113.7 ± 11.0 | -26.2 [-37.7, -14.8] s | -18.7 % | 0.0020 | 0.0137 | better | no |
| bus | `delay_mean` | 62.6 ± 2.6 | 47.6 ± 4.2 | -15.0 [-18.6, -11.3] s | -23.9 % | 0.0020 | 0.0137 | better | no |
| bus | `headway_std` | 21.6 ± 3.4 | 23.4 ± 3.1 | +1.9 [-0.9, 4.6] s | 8.7 % | 0.1602 | 0.1602 | worse | **yes** |
| pedestrian | `ped_wait_mean` | 22.2 ± 0.7 | 23.2 ± 0.7 | +1.0 [0.4, 1.6] s | 4.6 % | 0.0098 | 0.0293 | worse | no |
| pedestrian | `ped_wait_single_max` | 87.3 ± 0.5 | 88.0 ± 0.0 | +0.7 [0.4, 1.0] s | 0.8 % | 0.0156 | 0.0312 | worse | no |
| ambulance | `time_loss_mean` | 112.5 ± 48.7 | 68.2 ± 25.0 | -44.4 [-65.2, -23.6] s | -39.4 % | 0.0020 | 0.0137 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- pedestrian `ped_wait_single_mean`: 18.3 → 19.2 s (+5.3 %, p 0.0098)
- pedestrian `ped_wait_single_p95`: 70.5 → 74.2 s (+5.2 %, p 0.0020)
- car `time_loss_mean__arm_W`: 82.9 → 89.7 s (+8.2 %, p 0.0840)
- car `delay_total_mean__arm_W`: 83.0 → 89.8 s (+8.2 %, p 0.0840)
- bus `headway_std__line_24`: 3.76 → 4.17 s (+11.0 %, p 0.3223)
- bus `headway_std__line_57`: 20.9 → 31.8 s (+52.3 %, p 0.0020)
- pedestrian `ped_wait_single_mean__crossing_NB`: 9.2 → 10.1 s (+9.4 %, p 0.0020)
- pedestrian `ped_wait_single_mean__crossing_S`: 27.0 → 29.8 s (+10.6 %, p 0.0039)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.82 → 7.60 s (+11.5 %, p 0.0273)
- pedestrian `ped_wait_single_max__crossing_NB`: 41.6 → 58.7 s (+41.1 %, p 0.0020)
- pedestrian `ped_wait_single_max__crossing_WB`: 41.2 → 64.3 s (+56.1 %, p 0.0020)
- pedestrian `ped_curb_wait_mean`: 19.2 → 20.2 s (+5.2 %, p 0.0137)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.8 → 10.8 s (+9.4 %, p 0.0039)
- pedestrian `ped_curb_wait_mean__crossing_S`: 28.3 → 31.2 s (+10.3 %, p 0.0039)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.40 → 8.17 s (+10.3 %, p 0.0273)
- pedestrian `ped_curb_wait_max__crossing_NB`: 41.8 → 59.0 s (+41.1 %, p 0.0020)
- pedestrian `ped_curb_wait_max__crossing_WB`: 41.3 → 64.5 s (+56.2 %, p 0.0020)
- junction `box_halt_red_s`: 41.3 → 50.9 s (+23.2 %, p 0.4902)
- junction `exit_blocked_green_s`: 8.0 → 11.9 s (+48.8 %, p 0.0391)
