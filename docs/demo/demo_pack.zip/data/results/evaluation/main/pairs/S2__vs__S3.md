**S2** (`pitie_rules`) vs **S3** (`pitie_rl_s3`), family `main`, role *confirmatory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S2 mean ± sd | S3 mean ± sd | S3 − S2 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 56.6 ± 7.2 | 56.2 ± 4.3 | -0.3 [-3.2, 2.5] s | -0.6 % | 0.9219 | 1.0000 | better | no |
| car | `wait_p95` | 111.6 ± 19.9 | 113.7 ± 11.0 | +2.1 [-6.8, 11.0] s | 1.9 % | 0.4160 | 1.0000 | worse | no |
| bus | `delay_mean` | 56.1 ± 4.0 | 47.6 ± 4.2 | -8.5 [-12.3, -4.7] s | -15.2 % | 0.0059 | 0.0410 | better | no |
| bus | `headway_std` | 23.3 ± 3.2 | 23.4 ± 3.1 | +0.1 [-2.4, 2.7] s | 0.5 % | 0.8457 | 1.0000 | worse | no |
| pedestrian | `ped_wait_mean` | 22.3 ± 0.8 | 23.2 ± 0.7 | +0.9 [0.1, 1.6] s | 3.8 % | 0.0645 | 0.3867 | worse | no |
| pedestrian | `ped_wait_single_max` | 88.0 ± 0.0 | 88.0 ± 0.0 | +0.0 [0.0, 0.0] s | 0.0 % | 1.0000 | 1.0000 | same | no |
| ambulance | `time_loss_mean` | 76.7 ± 41.6 | 68.2 ± 25.0 | -8.5 [-32.1, 15.0] s | -11.1 % | 0.5566 | 1.0000 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- car `time_loss_mean__arm_W`: 69.5 → 89.7 s (+29.2 %, p 0.0020)
- car `delay_total_mean__arm_W`: 69.5 → 89.8 s (+29.2 %, p 0.0020)
- bus `delay_mean__flow_24_E`: 52.5 → 56.1 s (+6.9 %, p 0.4922)
- ambulance `stop_duration_mean`: 34.8 → 38.5 s (+10.6 %, p 0.6523)
- bus `headway_std__line_24`: 3.73 → 4.17 s (+11.8 %, p 0.4316)
- bus `headway_std__line_57`: 27.7 → 31.8 s (+15.0 %, p 0.1602)
- pedestrian `ped_wait_single_mean__crossing_NB`: 9.1 → 10.1 s (+10.3 %, p 0.0039)
- pedestrian `ped_wait_single_mean__crossing_S`: 27.7 → 29.8 s (+7.6 %, p 0.0137)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.87 → 7.60 s (+10.7 %, p 0.0098)
- pedestrian `ped_wait_single_max__crossing_NB`: 45.3 → 58.7 s (+29.6 %, p 0.0020)
- pedestrian `ped_wait_single_max__crossing_WB`: 44.8 → 64.3 s (+43.5 %, p 0.0020)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.8 → 10.8 s (+10.2 %, p 0.0059)
- pedestrian `ped_curb_wait_mean__crossing_S`: 29.0 → 31.2 s (+7.6 %, p 0.0137)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.42 → 8.17 s (+10.1 %, p 0.0195)
- pedestrian `ped_curb_wait_max__crossing_NB`: 45.9 → 59.0 s (+28.5 %, p 0.0020)
- pedestrian `ped_curb_wait_max__crossing_WB`: 45.2 → 64.5 s (+42.7 %, p 0.0020)
- junction `box_halt_red_s`: 41.5 → 50.9 s (+22.7 %, p 0.3438)
- junction `exit_blocked_green_s`: 10.8 → 11.9 s (+10.2 %, p 0.6328)
