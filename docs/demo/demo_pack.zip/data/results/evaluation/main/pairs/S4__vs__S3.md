**S4** (`pitie_rl_s3_nopreempt`) vs **S3** (`pitie_rl_s3`), family `main`, role *exploratory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S4 mean ± sd | S3 mean ± sd | S3 − S4 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 56.1 ± 4.0 | 56.2 ± 4.3 | +0.2 [-0.7, 1.0] s | 0.3 % | 0.8203 | 1.0000 | worse | no |
| car | `wait_p95` | 112.9 ± 10.9 | 113.7 ± 11.0 | +0.8 [-1.0, 2.6] s | 0.7 % | 0.2188 | 1.0000 | worse | no |
| bus | `delay_mean` | 47.4 ± 2.6 | 47.6 ± 4.2 | +0.2 [-1.5, 1.9] s | 0.4 % | 0.8203 | 1.0000 | worse | no |
| bus | `headway_std` | 23.3 ± 2.5 | 23.4 ± 3.1 | +0.1 [-1.4, 1.6] s | 0.4 % | 0.9102 | 1.0000 | worse | no |
| pedestrian | `ped_wait_mean` | 23.1 ± 1.0 | 23.2 ± 0.7 | +0.1 [-0.4, 0.6] s | 0.4 % | 0.9102 | 1.0000 | worse | no |
| pedestrian | `ped_wait_single_max` | 88.0 ± 0.0 | 88.0 ± 0.0 | +0.0 [0.0, 0.0] s | 0.0 % | 1.0000 | 1.0000 | same | no |
| ambulance | `time_loss_mean` | 92.2 ± 30.5 | 68.2 ± 25.0 | -24.1 [-36.8, -11.4] s | -26.1 % | 0.0039 | 0.0273 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- bus `delay_mean__flow_91_E`: 56.4 → 59.8 s (+6.0 %, p 0.2031)
- bus `headway_std__line_24`: 3.75 → 4.17 s (+11.3 %, p 0.3594)
- pedestrian `ped_wait_single_max__crossing_WB`: 59.5 → 64.3 s (+8.1 %, p 0.0312)
- pedestrian `ped_curb_wait_max__crossing_WB`: 60.0 → 64.5 s (+7.5 %, p 0.0312)
