**S1** (`pitie_actuated`) vs **S2** (`pitie_rules`), family `main`, role *confirmatory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S1 mean ± sd | S2 mean ± sd | S2 − S1 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 65.8 ± 11.3 | 56.6 ± 7.2 | -9.2 [-12.6, -5.9] s | -14.0 % | 0.0020 | 0.0137 | better | no |
| car | `wait_p95` | 140.0 ± 22.7 | 111.6 ± 19.9 | -28.3 [-39.8, -16.9] s | -20.2 % | 0.0020 | 0.0137 | better | no |
| bus | `delay_mean` | 62.6 ± 2.6 | 56.1 ± 4.0 | -6.4 [-10.3, -2.6] s | -10.3 % | 0.0098 | 0.0488 | better | no |
| bus | `headway_std` | 21.6 ± 3.4 | 23.3 ± 3.2 | +1.8 [-1.1, 4.6] s | 8.1 % | 0.2324 | 0.4648 | worse | **yes** |
| pedestrian | `ped_wait_mean` | 22.2 ± 0.7 | 22.3 ± 0.8 | +0.2 [-0.4, 0.8] s | 0.7 % | 0.4316 | 0.4648 | worse | no |
| pedestrian | `ped_wait_single_max` | 87.3 ± 0.5 | 88.0 ± 0.0 | +0.7 [0.4, 1.0] s | 0.8 % | 0.0156 | 0.0488 | worse | no |
| ambulance | `time_loss_mean` | 112.5 ± 48.7 | 76.7 ± 41.6 | -35.8 [-58.8, -12.8] s | -31.8 % | 0.0098 | 0.0488 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- bus `depart_delay_max`: 4.80 → 5.20 s (+8.3 %, p 0.7500)
- car `time_loss_mean__arm_S`: 44.9 → 48.4 s (+7.6 %, p 0.0020)
- car `delay_total_mean__arm_S`: 45.0 → 48.4 s (+7.7 %, p 0.0020)
- bus `headway_std__line_57`: 20.9 → 27.7 s (+32.4 %, p 0.0059)
- pedestrian `ped_wait_single_max__crossing_NB`: 41.6 → 45.3 s (+8.9 %, p 0.0156)
- pedestrian `ped_wait_single_max__crossing_WB`: 41.2 → 44.8 s (+8.7 %, p 0.0078)
- pedestrian `ped_curb_wait_max__crossing_NB`: 41.8 → 45.9 s (+9.8 %, p 0.0117)
- pedestrian `ped_curb_wait_max__crossing_WB`: 41.3 → 45.2 s (+9.4 %, p 0.0117)
- junction `exit_blocked_green_s`: 8.0 → 10.8 s (+35.0 %, p 0.0977)
