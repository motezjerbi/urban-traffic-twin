**S0** (`pitie_fixed`) vs **S1** (`pitie_actuated`), family `main`, role *part3*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S0 mean ± sd | S1 mean ± sd | S1 − S0 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 75.9 ± 12.9 | 65.8 ± 11.3 | -10.1 [-12.9, -7.2] s | -13.3 % | 0.0020 | 0.0137 | better | no |
| car | `wait_p95` | 164.5 ± 26.3 | 140.0 ± 22.7 | -24.5 [-42.3, -6.7] s | -14.9 % | 0.0020 | 0.0137 | better | no |
| bus | `delay_mean` | 61.0 ± 1.1 | 62.6 ± 2.6 | +1.5 [0.2, 2.9] s | 2.5 % | 0.0371 | 0.1484 | worse | no |
| bus | `headway_std` | 23.4 ± 0.3 | 21.6 ± 3.4 | -1.8 [-4.2, 0.5] s | -7.9 % | 0.0840 | 0.2520 | better | no |
| pedestrian | `ped_wait_mean` | 21.8 ± 0.7 | 22.2 ± 0.7 | +0.4 [-0.2, 0.9] s | 1.6 % | 0.2754 | 0.5508 | worse | no |
| pedestrian | `ped_wait_single_max` | 85.6 ± 0.5 | 87.3 ± 0.5 | +1.7 [1.2, 2.2] s | 2.0 % | 0.0020 | 0.0137 | worse | no |
| ambulance | `time_loss_mean` | 109.2 ± 52.5 | 112.5 ± 48.7 | +3.4 [-33.8, 40.6] s | 3.1 % | 0.9219 | 0.9219 | worse | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- ambulance `stops`: 1.30 → 1.60 (+23.1 %, p 0.3750)
- bus `depart_delay_mean`: 0.137 → 0.165 s (+20.2 %, p 0.0195)
- bus `depart_delay_max`: 3.00 → 4.80 s (+60.0 %, p 0.0312)
- bus `delay_mean__flow_24_W`: 49.1 → 57.6 s (+17.3 %, p 0.0273)
- bus `delay_mean__flow_57_N`: 53.5 → 66.9 s (+25.0 %, p 0.0020)
- pedestrian `ped_wait_single_mean__crossing_NB`: 8.63 → 9.19 s (+6.5 %, p 0.1641)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.46 → 6.82 s (+5.5 %, p 0.0488)
- pedestrian `ped_wait_single_mean__crossing_W`: 27.8 → 29.6 s (+6.3 %, p 0.0195)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.32 → 9.84 s (+5.6 %, p 0.1602)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.00 → 7.40 s (+5.8 %, p 0.0488)
- pedestrian `ped_curb_wait_mean__crossing_W`: 29.1 → 30.9 s (+6.2 %, p 0.0195)
- junction `box_foe_onsets`: 2.40 → 3.00 (+25.0 %, p 0.3711)
- junction `exit_blocked_s`: 24.5 → 25.9 s (+5.7 %, p 0.7188)
- junction `exit_blocked_green_s`: 1.80 → 8.00 s (+344.4 %, p 0.0020)
