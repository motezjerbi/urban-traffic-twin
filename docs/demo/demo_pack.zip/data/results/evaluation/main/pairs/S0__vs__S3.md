**S0** (`pitie_fixed`) vs **S3** (`pitie_rl_s3`), family `main`, role *confirmatory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S0 mean ± sd | S3 mean ± sd | S3 − S0 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 75.9 ± 12.9 | 56.2 ± 4.3 | -19.6 [-26.3, -12.9] s | -25.9 % | 0.0020 | 0.0137 | better | no |
| car | `wait_p95` | 164.5 ± 26.3 | 113.7 ± 11.0 | -50.7 [-65.4, -36.1] s | -30.8 % | 0.0020 | 0.0137 | better | no |
| bus | `delay_mean` | 61.0 ± 1.1 | 47.6 ± 4.2 | -13.4 [-16.5, -10.3] s | -22.0 % | 0.0020 | 0.0137 | better | no |
| bus | `headway_std` | 23.4 ± 0.3 | 23.4 ± 3.1 | +0.0 [-2.1, 2.2] s | 0.1 % | 0.7695 | 0.7695 | worse | no |
| pedestrian | `ped_wait_mean` | 21.8 ± 0.7 | 23.2 ± 0.7 | +1.4 [0.7, 2.0] s | 6.3 % | 0.0020 | 0.0137 | worse | **yes** |
| pedestrian | `ped_wait_single_max` | 85.6 ± 0.5 | 88.0 ± 0.0 | +2.4 [2.0, 2.8] s | 2.8 % | 0.0020 | 0.0137 | worse | no |
| ambulance | `time_loss_mean` | 109.2 ± 52.5 | 68.2 ± 25.0 | -41.0 [-75.4, -6.6] s | -37.6 % | 0.0273 | 0.0547 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- bus `depart_delay_mean`: 0.137 → 0.166 s (+20.9 %, p 0.0078)
- bus `depart_delay_max`: 3.00 → 4.80 s (+60.0 %, p 0.0312)
- pedestrian `ped_wait_single_mean`: 17.9 → 19.2 s (+7.3 %, p 0.0020)
- bus `headway_std__line_24`: 3.91 → 4.17 s (+6.7 %, p 0.5566)
- bus `headway_std__line_57`: 23.4 → 31.8 s (+35.8 %, p 0.0020)
- pedestrian `ped_wait_single_mean__crossing_NB`: 8.6 → 10.1 s (+16.5 %, p 0.0020)
- pedestrian `ped_wait_single_mean__crossing_S`: 28.4 → 29.8 s (+5.2 %, p 0.0488)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.46 → 7.60 s (+17.7 %, p 0.0039)
- pedestrian `ped_wait_single_max__crossing_NB`: 40.9 → 58.7 s (+43.5 %, p 0.0020)
- pedestrian `ped_wait_single_max__crossing_WB`: 40.9 → 64.3 s (+57.2 %, p 0.0020)
- pedestrian `ped_curb_wait_mean`: 18.9 → 20.2 s (+7.0 %, p 0.0020)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.3 → 10.8 s (+15.5 %, p 0.0020)
- pedestrian `ped_curb_wait_mean__crossing_S`: 29.7 → 31.2 s (+5.1 %, p 0.0488)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.00 → 8.17 s (+16.7 %, p 0.0039)
- pedestrian `ped_curb_wait_max__crossing_NB`: 41.2 → 59.0 s (+43.2 %, p 0.0020)
- pedestrian `ped_curb_wait_max__crossing_WB`: 40.9 → 64.5 s (+57.7 %, p 0.0020)
- junction `box_halt_red_s`: 45.8 → 50.9 s (+11.1 %, p 0.4961)
- junction `exit_blocked_green_s`: 1.8 → 11.9 s (+561.1 %, p 0.0020)
