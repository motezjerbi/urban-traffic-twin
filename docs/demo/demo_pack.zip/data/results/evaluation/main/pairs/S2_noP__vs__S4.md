**S2_noP** (`pitie_rules_nopreempt`) vs **S4** (`pitie_rl_s3_nopreempt`), family `main`, role *exploratory*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S2_noP mean ± sd | S4 mean ± sd | S4 − S2_noP [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 55.9 ± 6.7 | 56.1 ± 4.0 | +0.2 [-2.1, 2.5] s | 0.4 % | 0.4316 | 1.0000 | worse | no |
| car | `wait_p95` | 109.6 ± 19.7 | 112.9 ± 10.9 | +3.4 [-4.7, 11.4] s | 3.1 % | 0.4160 | 1.0000 | worse | no |
| bus | `delay_mean` | 57.2 ± 5.4 | 47.4 ± 2.6 | -9.8 [-13.5, -6.0] s | -17.1 % | 0.0020 | 0.0137 | better | no |
| bus | `headway_std` | 23.4 ± 3.5 | 23.3 ± 2.5 | -0.1 [-2.2, 2.0] s | -0.3 % | 0.7695 | 1.0000 | better | no |
| pedestrian | `ped_wait_mean` | 22.1 ± 0.6 | 23.1 ± 1.0 | +1.0 [0.2, 1.9] s | 4.6 % | 0.0273 | 0.1641 | worse | no |
| pedestrian | `ped_wait_single_max` | 88.0 ± 0.0 | 88.0 ± 0.0 | +0.0 [0.0, 0.0] s | 0.0 % | 1.0000 | 1.0000 | same | no |
| ambulance | `time_loss_mean` | 100.6 ± 43.0 | 92.2 ± 30.5 | -8.3 [-37.9, 21.2] s | -8.3 % | 0.8457 | 1.0000 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- pedestrian `ped_wait_single_mean`: 18.2 → 19.1 s (+5.3 %, p 0.0195)
- car `time_loss_mean__arm_W`: 63.7 → 87.6 s (+37.5 %, p 0.0020)
- car `delay_total_mean__arm_W`: 63.8 → 87.6 s (+37.5 %, p 0.0020)
- bus `delay_mean__flow_24_E`: 52.4 → 55.8 s (+6.5 %, p 0.5566)
- ambulance `stop_duration_mean`: 51.2 → 61.6 s (+20.3 %, p 0.2871)
- pedestrian `ped_wait_single_mean__crossing_NB`: 8.93 → 9.86 s (+10.4 %, p 0.0059)
- pedestrian `ped_wait_single_mean__crossing_S`: 27.8 → 30.0 s (+8.0 %, p 0.0195)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.78 → 7.42 s (+9.5 %, p 0.1309)
- pedestrian `ped_wait_single_max__crossing_NB`: 45.4 → 59.5 s (+31.1 %, p 0.0020)
- pedestrian `ped_wait_single_max__crossing_WB`: 44.1 → 59.5 s (+34.9 %, p 0.0020)
- pedestrian `ped_curb_wait_mean`: 19.1 → 20.1 s (+5.2 %, p 0.0273)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.6 → 10.6 s (+10.2 %, p 0.0059)
- pedestrian `ped_curb_wait_mean__crossing_S`: 29.1 → 31.4 s (+7.9 %, p 0.0195)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.32 → 7.99 s (+9.2 %, p 0.1055)
- pedestrian `ped_curb_wait_max__crossing_NB`: 46.2 → 59.9 s (+29.7 %, p 0.0020)
- pedestrian `ped_curb_wait_max__crossing_WB`: 44.4 → 60.0 s (+35.1 %, p 0.0020)
- junction `box_halt_red_s`: 34.6 → 54.2 s (+56.6 %, p 0.0117)
- junction `box_foe_onsets`: 1.50 → 2.80 (+86.7 %, p 0.0156)
- junction `exit_blocked_green_s`: 9.1 → 14.1 s (+54.9 %, p 0.0586)
