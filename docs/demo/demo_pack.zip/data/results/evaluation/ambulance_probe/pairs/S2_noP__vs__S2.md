**S2_noP** (`pitie_amb_rules_nopreempt`) vs **S2** (`pitie_amb_rules`), family `ambulance_probe`, role *secondary*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S2_noP mean ± sd | S2 mean ± sd | S2 − S2_noP [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 56.0 ± 6.6 | 58.6 ± 6.7 | +2.6 [1.0, 4.1] s | 4.6 % | 0.0039 | 0.0234 | worse | no |
| car | `wait_p95` | 113.3 ± 23.2 | 119.7 ± 20.8 | +6.4 [0.0, 12.7] s | 5.6 % | 0.0625 | 0.3125 | worse | **yes** |
| bus | `delay_mean` | 57.6 ± 2.9 | 59.1 ± 6.2 | +1.5 [-1.7, 4.7] s | 2.6 % | 0.4316 | 1.0000 | worse | no |
| bus | `headway_std` | 24.4 ± 3.3 | 24.5 ± 3.0 | +0.1 [-1.6, 1.8] s | 0.5 % | 0.6250 | 1.0000 | worse | no |
| pedestrian | `ped_wait_mean` | 22.3 ± 0.7 | 22.2 ± 0.5 | -0.1 [-0.8, 0.5] s | -0.7 % | 0.8457 | 1.0000 | better | no |
| pedestrian | `ped_wait_single_max` | 88.0 ± 0.0 | 88.0 ± 0.0 | +0.0 [0.0, 0.0] s | 0.0 % | 1.0000 | 1.0000 | same | no |
| ambulance | `time_loss_mean` | 72.0 ± 21.2 | 53.6 ± 15.6 | -18.3 [-31.3, -5.4] s | -25.5 % | 0.0020 | 0.0137 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- ambulance `stops`: 1.13 → 1.23 (+8.9 %, p 0.1758)
- bus `depart_delay_max`: 4.30 → 4.80 s (+11.6 %, p 1.0000)
- car `wait_mean`: 43.6 → 45.9 s (+5.2 %, p 0.0020)
- car `depart_delay_max`: 39.1 → 49.9 s (+27.6 %, p 0.1934)
- car `time_loss_mean__arm_W`: 64.4 → 71.9 s (+11.7 %, p 0.0098)
- car `delay_total_mean__arm_W`: 64.4 → 72.0 s (+11.7 %, p 0.0098)
- bus `delay_mean__flow_24_W`: 49.5 → 57.8 s (+16.7 %, p 0.1309)
- bus `delay_mean__flow_91_W`: 53.4 → 57.9 s (+8.3 %, p 0.1309)
- bus `headway_std__line_91`: 28.5 → 30.4 s (+6.6 %, p 0.2754)
- junction `exit_blocked_green_s`: 7.60 → 9.90 s (+30.3 %, p 0.2109)
