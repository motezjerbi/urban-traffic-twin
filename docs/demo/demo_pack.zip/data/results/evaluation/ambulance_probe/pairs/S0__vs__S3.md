**S0** (`pitie_amb_fixed`) vs **S3** (`pitie_amb_rl_s3`), family `ambulance_probe`, role *secondary*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S0 mean ± sd | S3 mean ± sd | S3 − S0 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 77.2 ± 11.8 | 59.4 ± 9.8 | -17.8 [-21.8, -13.7] s | -23.0 % | 0.0020 | 0.0137 | better | no |
| car | `wait_p95` | 170.0 ± 26.0 | 124.7 ± 27.1 | -45.3 [-62.1, -28.4] s | -26.6 % | 0.0020 | 0.0137 | better | no |
| bus | `delay_mean` | 61.2 ± 1.8 | 49.7 ± 5.5 | -11.5 [-15.5, -7.4] s | -18.7 % | 0.0020 | 0.0137 | better | no |
| bus | `headway_std` | 23.5 ± 0.4 | 24.7 ± 3.3 | +1.2 [-1.0, 3.5] s | 5.2 % | 0.3750 | 0.3750 | worse | **yes** |
| pedestrian | `ped_wait_mean` | 21.8 ± 0.7 | 23.2 ± 0.7 | +1.4 [0.8, 2.0] s | 6.4 % | 0.0039 | 0.0137 | worse | **yes** |
| pedestrian | `ped_wait_single_max` | 85.4 ± 0.5 | 88.0 ± 0.0 | +2.6 [2.2, 3.0] s | 3.0 % | 0.0020 | 0.0137 | worse | no |
| ambulance | `time_loss_mean` | 128.2 ± 18.1 | 51.5 ± 15.3 | -76.7 [-89.0, -64.4] s | -59.8 % | 0.0020 | 0.0137 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- bus `depart_delay_mean`: 0.141 → 0.167 s (+18.0 %, p 0.0078)
- bus `depart_delay_max`: 3.00 → 4.90 s (+63.3 %, p 0.0312)
- pedestrian `ped_wait_single_mean`: 17.9 → 19.3 s (+7.4 %, p 0.0039)
- bus `headway_std__line_57`: 23.4 → 30.1 s (+28.7 %, p 0.0020)
- pedestrian `ped_wait_single_mean__crossing_NB`: 8.67 → 9.79 s (+12.9 %, p 0.0371)
- pedestrian `ped_wait_single_mean__crossing_S`: 28.4 → 30.2 s (+6.5 %, p 0.0273)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.46 → 7.82 s (+21.0 %, p 0.0020)
- pedestrian `ped_wait_single_max__crossing_NB`: 41.3 → 58.3 s (+41.2 %, p 0.0020)
- pedestrian `ped_wait_single_max__crossing_WB`: 40.8 → 57.6 s (+41.2 %, p 0.0020)
- pedestrian `ped_curb_wait_mean`: 18.9 → 20.3 s (+7.2 %, p 0.0039)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.4 → 10.4 s (+11.6 %, p 0.0488)
- pedestrian `ped_curb_wait_mean__crossing_S`: 29.7 → 31.6 s (+6.4 %, p 0.0195)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 6.99 → 8.42 s (+20.5 %, p 0.0039)
- pedestrian `ped_curb_wait_max__crossing_NB`: 41.4 → 58.7 s (+41.8 %, p 0.0020)
- pedestrian `ped_curb_wait_max__crossing_WB`: 40.8 → 57.7 s (+41.4 %, p 0.0020)
- junction `box_halt_red_s`: 46.7 → 60.1 s (+28.7 %, p 0.2422)
- junction `box_foe_onsets`: 2.20 → 3.60 (+63.6 %, p 0.1406)
- junction `exit_blocked_green_s`: 2.2 → 16.5 s (+650.0 %, p 0.0020)
