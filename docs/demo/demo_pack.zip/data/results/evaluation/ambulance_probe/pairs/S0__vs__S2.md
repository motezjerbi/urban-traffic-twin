**S0** (`pitie_amb_fixed`) vs **S2** (`pitie_amb_rules`), family `ambulance_probe`, role *secondary*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S0 mean ± sd | S2 mean ± sd | S2 − S0 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 77.2 ± 11.8 | 58.6 ± 6.7 | -18.6 [-23.4, -13.8] s | -24.1 % | 0.0020 | 0.0137 | better | no |
| car | `wait_p95` | 170.0 ± 26.0 | 119.7 ± 20.8 | -50.3 [-68.4, -32.2] s | -29.6 % | 0.0020 | 0.0137 | better | no |
| bus | `delay_mean` | 61.2 ± 1.8 | 59.1 ± 6.2 | -2.1 [-6.3, 2.2] s | -3.4 % | 0.3750 | 0.8262 | better | no |
| bus | `headway_std` | 23.5 ± 0.4 | 24.5 ± 3.0 | +1.0 [-1.2, 3.2] s | 4.3 % | 0.4316 | 0.8262 | worse | no |
| pedestrian | `ped_wait_mean` | 21.8 ± 0.7 | 22.2 ± 0.5 | +0.4 [-0.4, 1.1] s | 1.7 % | 0.2754 | 0.8262 | worse | no |
| pedestrian | `ped_wait_single_max` | 85.4 ± 0.5 | 88.0 ± 0.0 | +2.6 [2.2, 3.0] s | 3.0 % | 0.0020 | 0.0137 | worse | no |
| ambulance | `time_loss_mean` | 128.2 ± 18.1 | 53.6 ± 15.6 | -74.5 [-90.6, -58.5] s | -58.2 % | 0.0020 | 0.0137 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- bus `depart_delay_mean`: 0.141 → 0.156 s (+10.5 %, p 0.0312)
- bus `depart_delay_max`: 3.00 → 4.80 s (+60.0 %, p 0.0312)
- car `time_loss_mean__arm_S`: 43.5 → 48.1 s (+10.5 %, p 0.0020)
- car `delay_total_mean__arm_S`: 43.5 → 48.1 s (+10.6 %, p 0.0020)
- bus `delay_mean__flow_24_W`: 48.3 → 57.8 s (+19.8 %, p 0.0645)
- bus `delay_mean__flow_57_N`: 53.5 → 61.7 s (+15.3 %, p 0.0371)
- bus `headway_std__line_57`: 23.4 → 28.9 s (+23.4 %, p 0.0098)
- pedestrian `ped_wait_single_mean__crossing_NB`: 8.67 → 9.22 s (+6.4 %, p 0.0371)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.46 → 6.87 s (+6.2 %, p 0.1934)
- pedestrian `ped_wait_single_mean__crossing_W`: 27.8 → 29.4 s (+5.5 %, p 0.1055)
- pedestrian `ped_wait_single_max__crossing_NB`: 41.3 → 45.1 s (+9.2 %, p 0.0215)
- pedestrian `ped_wait_single_max__crossing_WB`: 40.8 → 44.2 s (+8.3 %, p 0.0039)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.36 → 9.88 s (+5.6 %, p 0.0488)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 6.99 → 7.41 s (+6.1 %, p 0.2324)
- pedestrian `ped_curb_wait_mean__crossing_W`: 29.1 → 30.7 s (+5.2 %, p 0.0840)
- pedestrian `ped_curb_wait_max__crossing_NB`: 41.4 → 45.1 s (+8.9 %, p 0.0215)
- pedestrian `ped_curb_wait_max__crossing_WB`: 40.8 → 44.2 s (+8.3 %, p 0.0039)
- junction `box_foe_onsets`: 2.20 → 2.80 (+27.3 %, p 0.4414)
- junction `exit_blocked_green_s`: 2.20 → 9.90 s (+350.0 %, p 0.0020)
