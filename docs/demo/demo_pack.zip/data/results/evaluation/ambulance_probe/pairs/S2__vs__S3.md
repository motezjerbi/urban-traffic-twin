**S2** (`pitie_amb_rules`) vs **S3** (`pitie_amb_rl_s3`), family `ambulance_probe`, role *secondary*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S2 mean ± sd | S3 mean ± sd | S3 − S2 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 58.6 ± 6.7 | 59.4 ± 9.8 | +0.9 [-2.4, 4.1] s | 1.5 % | 0.8457 | 1.0000 | worse | no |
| car | `wait_p95` | 119.7 ± 20.8 | 124.7 ± 27.1 | +5.0 [-4.9, 15.0] s | 4.2 % | 0.3750 | 1.0000 | worse | no |
| bus | `delay_mean` | 59.1 ± 6.2 | 49.7 ± 5.5 | -9.4 [-13.7, -5.1] s | -15.9 % | 0.0020 | 0.0137 | better | no |
| bus | `headway_std` | 24.5 ± 3.0 | 24.7 ± 3.3 | +0.2 [-2.7, 3.2] s | 0.9 % | 0.9219 | 1.0000 | worse | no |
| pedestrian | `ped_wait_mean` | 22.2 ± 0.5 | 23.2 ± 0.7 | +1.0 [0.5, 1.6] s | 4.6 % | 0.0039 | 0.0234 | worse | no |
| pedestrian | `ped_wait_single_max` | 88.0 ± 0.0 | 88.0 ± 0.0 | +0.0 [0.0, 0.0] s | 0.0 % | 1.0000 | 1.0000 | same | no |
| ambulance | `time_loss_mean` | 53.6 ± 15.6 | 51.5 ± 15.3 | -2.1 [-11.8, 7.5] s | -4.0 % | 0.5566 | 1.0000 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- ambulance `depart_delay_mean`: 0.07 → 1.61 s (+2160.0 %, p 1.0000)
- ambulance `depart_delay_max`: 0.5 → 11.3 s (+2160.0 %, p 1.0000)
- bus `depart_delay_mean`: 0.156 → 0.167 s (+6.8 %, p 0.1406)
- car `depart_delay_mean`: 0.641 → 0.930 s (+45.0 %, p 0.4922)
- pedestrian `ped_wait_single_mean`: 18.3 → 19.3 s (+5.2 %, p 0.0039)
- car `time_loss_mean__arm_W`: 71.9 → 90.8 s (+26.3 %, p 0.0020)
- car `delay_total_mean__arm_W`: 72.0 → 91.0 s (+26.4 %, p 0.0020)
- bus `delay_mean__flow_24_E`: 57.1 → 64.9 s (+13.7 %, p 0.1309)
- pedestrian `ped_wait_single_mean__crossing_NB`: 9.22 → 9.79 s (+6.1 %, p 0.1055)
- pedestrian `ped_wait_single_mean__crossing_S`: 27.4 → 30.2 s (+10.3 %, p 0.0020)
- pedestrian `ped_wait_single_mean__crossing_WB`: 6.87 → 7.82 s (+13.8 %, p 0.0098)
- pedestrian `ped_wait_single_max__crossing_NB`: 45.1 → 58.3 s (+29.3 %, p 0.0020)
- pedestrian `ped_wait_single_max__crossing_WB`: 44.2 → 57.6 s (+30.3 %, p 0.0020)
- pedestrian `ped_curb_wait_mean`: 19.3 → 20.3 s (+5.2 %, p 0.0039)
- pedestrian `ped_curb_wait_mean__crossing_NB`: 9.9 → 10.4 s (+5.7 %, p 0.1055)
- pedestrian `ped_curb_wait_mean__crossing_S`: 28.7 → 31.6 s (+10.2 %, p 0.0020)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.41 → 8.42 s (+13.6 %, p 0.0137)
- pedestrian `ped_curb_wait_max__crossing_NB`: 45.1 → 58.7 s (+30.2 %, p 0.0020)
- pedestrian `ped_curb_wait_max__crossing_WB`: 44.2 → 57.7 s (+30.5 %, p 0.0020)
- junction `box_halt_red_s`: 45.8 → 60.1 s (+31.2 %, p 0.4805)
- junction `box_foe_onsets`: 2.80 → 3.60 (+28.6 %, p 0.5625)
- junction `exit_blocked_green_s`: 9.9 → 16.5 s (+66.7 %, p 0.0176)
