**S4** (`pitie_amb_rl_s3_nopreempt`) vs **S3** (`pitie_amb_rl_s3`), family `ambulance_probe`, role *secondary*: 10 seeds, one demand. Exact two-sided Wilcoxon, Holm over the 7 headline KPIs of this pair only; α = 0.05.

| User | KPI | S4 mean ± sd | S3 mean ± sd | S3 − S4 [95 % CI] | Change | p | p (Holm) | Effect | Equity flag |
|---|---|---|---|---|---|---|---|---|---|
| car | `time_loss_mean` | 57.2 ± 5.3 | 59.4 ± 9.8 | +2.2 [-1.4, 5.8] s | 3.9 % | 0.4922 | 1.0000 | worse | no |
| car | `wait_p95` | 116.2 ± 15.1 | 124.7 ± 27.1 | +8.5 [-1.6, 18.6] s | 7.3 % | 0.0703 | 0.4219 | worse | **yes** |
| bus | `delay_mean` | 48.2 ± 4.5 | 49.7 ± 5.5 | +1.6 [-1.9, 5.1] s | 3.3 % | 0.3750 | 1.0000 | worse | no |
| bus | `headway_std` | 22.2 ± 3.8 | 24.7 ± 3.3 | +2.5 [-0.9, 5.9] s | 11.3 % | 0.1934 | 0.9668 | worse | **yes** |
| pedestrian | `ped_wait_mean` | 23.3 ± 0.4 | 23.2 ± 0.7 | -0.0 [-0.6, 0.5] s | -0.2 % | 0.4922 | 1.0000 | better | no |
| pedestrian | `ped_wait_single_max` | 88.0 ± 0.0 | 88.0 ± 0.0 | +0.0 [0.0, 0.0] s | 0.0 % | 1.0000 | 1.0000 | same | no |
| ambulance | `time_loss_mean` | 95.4 ± 17.7 | 51.5 ± 15.3 | -43.9 [-52.6, -35.2] s | -46.0 % | 0.0020 | 0.0137 | better | no |

Other KPIs more than 5 % worse (secondary, unadjusted p):

- ambulance `depart_delay_mean`: 0.73 → 1.61 s (+121.6 %, p 1.0000)
- ambulance `depart_delay_max`: 5.1 → 11.3 s (+121.6 %, p 1.0000)
- bus `depart_delay_mean`: 0.153 → 0.167 s (+9.0 %, p 0.1055)
- bus `depart_delay_max`: 4.20 → 4.90 s (+16.7 %, p 0.2500)
- car `depart_delay_mean`: 0.462 → 0.930 s (+101.0 %, p 0.0488)
- car `depart_delay_max`: 29.6 → 48.3 s (+63.2 %, p 0.0430)
- car `time_loss_mean__arm_W`: 84.9 → 90.8 s (+7.0 %, p 0.3750)
- car `delay_total_mean__arm_W`: 84.9 → 91.0 s (+7.1 %, p 0.3750)
- bus `delay_mean__flow_57_N`: 46.3 → 52.0 s (+12.1 %, p 0.1934)
- bus `delay_mean__flow_91_W`: 36.1 → 41.6 s (+15.2 %, p 0.0098)
- bus `headway_std__line_91`: 25.0 → 29.9 s (+19.5 %, p 0.1934)
- pedestrian `ped_wait_single_mean__crossing_WB`: 7.23 → 7.82 s (+8.1 %, p 0.0645)
- pedestrian `ped_curb_wait_mean__crossing_WB`: 7.78 → 8.42 s (+8.2 %, p 0.0645)
